<?php
$session_data_head1 = $this->session->userdata('session_data_head');
if (isset($session_data_head1)) {
    
} else {
    header($this->config->item('header'));
}
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Edit Purchase Order
                </h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url() . 'Home/index/' ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">Purchase Order</a></li>
                    <li class="active">Purchase Order Details</li>
                </ol>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-info">
                            <div class="box-header">
                                <h3 class="box-title">Edit Purchase Order</h3>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">

                                <!-- Start Flash Message -->
                                <?php if ($this->session->flashdata('SUCCESSMSG')) { ?>
                                    <div role="alert" class="alert alert-success">
                                        <button data-dismiss="alert" class="close" type="button"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                        <strong>Well done!!</strong> <?= $this->session->flashdata('SUCCESSMSG') ?>
                                    </div>
                                <?php } ?>

                                <?php if ($this->session->flashdata('INFOMSG')) { ?>
                                    <div role="alert" class="alert alert-info">
                                        <button data-dismiss="alert" class="close" type="button"><span aria-hidden="true">x</span><span class="sr-only">Close</span></button>
                                        <strong>Oops!!</strong> <?= $this->session->flashdata('INFOMSG') ?>
                                    </div>
                                <?php } ?>
                                <!-- End Flash Message -->

                                <form class="form-horizontal form_overlay" name="add_name" id="add_name" method="post" action="<?php echo base_url(); ?>SupplierController/edit_purchase_order" enctype="multipart/form-data">
                                    <div class="row">

                                        <div class="col-md-12">
                                            <div class="form-group row ">

                                                <input type="hidden" class="form-control input-sm"   name="gst_check" value="gst_check" id="gst_check">
                                                <input type="hidden" class="form-control input-sm" name="number" id="number" required="" value="<?php echo $po_data_group['number']; ?>">
                                                <input type="hidden" class="form-control input-sm" name="po_stock_check" value="po_stock_check" id="po_stock_check">
                                                <label for="inputEmail3" name="number" id="number" class="col-sm-12 control-label"><h2> PO:<b> <?php echo $po_data_group['number']; ?></b></h2></label>
                                            </div>
                                        </div>    

                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Company<span style="color: red;">*</span></label>
                                                <div class="col-sm-8">
                                                    <select class="form-control input-sm company_search_name" name="supplier_id" id="supplier_id" required id="">
                                                        <option value="">Select Company</option>
                                                        <?php
                                                        $company_name = $po_data_group['company_name'];

                                                        foreach ($result as $row) {
                                                            ?>
                                                            <option value="<?php echo $row->supplier_id ?>"  
                                                            <?php
                                                            if ($company_name == $row->company_name) {
                                                                echo 'selected="selected"';
                                                            }
                                                            ?> ><?php echo $row->company_name; ?></option>

                                                        <?php }
                                                        ?>
                                                    </select>  
                                                </div>
                                            </div>

                                            <div class="form-group row hide">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Payment Method</label>
                                                <div class="col-sm-8">
                                                    <select class="form-control input-sm "  name="payment_method" id="payment_method">
                                                        <option value="">Select Payment Method</option>
                                                        <option value="1">Cash</option>
                                                        <option value="2">Cheque</option>
                                                        <option value="3">NetBanking</option>
                                                    </select>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row ">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Order Date<span style="color: red;">*</span></label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control alldate  input-sm created-date" name="purchase_date" id="date" required="" value="<?php echo date('d-m-Y', strtotime($po_data_group['purchase_date'])); ?>" onkeydown="return false;">
                                                </div>
                                            </div>

                                            <div class="form-group row ">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Due Date<span style="color: red;">*</span></label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control input-sm payment-due-date-check currentDateWithSevendays" name="delivery_date" id="delivery_date" required="" value="<?php echo $po_data_group['delivery_date']; ?>" onkeydown="return false;">
                                                </div>
                                            </div>

                                            <div class="form-group row hide">
                                                <label for="inputEmail3" class="col-sm-4 control-label">P.O./S.O.</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control input-sm" readonly=""  placeholder="P.O./S.O." name="po" id="po"value="<?php echo $po_data_group['number']; ?>" >
                                                </div>
                                            </div>

                                            <div class="form-group row hide">
                                                <label for="inputEmail3" class="col-sm-4 control-label">PO Upload</label>
                                                <div class="col-sm-8">
                                                    <input type="file" class="form-control input-sm" name="po_upload" id="po_upload" value="<?php echo $po_data_group['po_upload']; ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Status</label>
                                                <div class="col-sm-6">


                                                    <select class="form-control input-sm "  name="status" id="status">

                                                        <?php if ($po_data_group['status'] == 1) { ?>
                                                            <option value="1" selected="">Draft</option>
                                                            <option value="2">Sent</option>
                                                            <option value="3">Viewed</option>
                                                            <option value="4">Approved</option> 
                                                            <option value="5">Rejected</option>
                                                            <option value="6">Canceled</option> 
                                                        <?php } ?>
                                                        <?php if ($po_data_group['status'] == 2) { ?>
                                                            <option value="1" >Draft</option>
                                                            <option value="2" selected="">Sent</option>
                                                            <option value="3">Viewed</option>
                                                            <option value="4">Approved</option> 
                                                            <option value="5">Rejected</option>
                                                            <option value="6">Canceled</option> 
                                                        <?php } ?>
                                                        <?php if ($po_data_group['status'] == 3) { ?>
                                                            <option value="1" >Draft</option>
                                                            <option value="2">Sent</option>
                                                            <option value="3" selected="">Viewed</option>
                                                            <option value="4">Approved</option> 
                                                            <option value="5">Rejected</option>
                                                            <option value="6">Canceled</option> 
                                                        <?php } ?>
                                                        <?php if ($po_data_group['status'] == 4) { ?>
                                                            <option value="1">Draft</option>
                                                            <option value="2">Sent</option>
                                                            <option value="3">Viewed</option>
                                                            <option value="4" selected="">Approved</option> 
                                                            <option value="5">Rejected</option>
                                                            <option value="6">Canceled</option> 
                                                        <?php } ?>
                                                        <?php if ($po_data_group['status'] == 5) { ?>
                                                            <option value="1" selected="">Draft</option>
                                                            <option value="2">Sent</option>
                                                            <option value="3">Viewed</option>
                                                            <option value="4">Approved</option> 
                                                            <option value="5" selected="">Rejected</option>
                                                            <option value="6">Canceled</option> 
                                                        <?php } ?>
                                                        <?php if ($po_data_group['status'] == 6) { ?>
                                                            <option value="1">Draft</option>
                                                            <option value="2">Sent</option>
                                                            <option value="3">Viewed</option>
                                                            <option value="4">Approved</option> 
                                                            <option value="5">Rejected</option>
                                                            <option value="6" selected="">Canceled</option> 
                                                        <?php } ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 hide">

                                            <div class="form-group row ">
                                                <label for="inputEmail3" id="subheading1" class="col-sm-4 control-label">Subheading</label>
                                                <div class="col-sm-8">
                                                    <input type="text" value="<?php echo $po_data_group['subheading']; ?>" class="form-control" name="subheading" id="subheading">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Footer</label>
                                                <div class="col-sm-8">
                                                    <textarea class="form-control" name="footer" id="footer" rows="3"><?php echo $po_data_group['footer']; ?></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Memo</label>
                                                <div class="col-sm-8">
                                                    <textarea class="form-control" name="memo" id="memo" rows="3"><?php echo $po_data_group['memo']; ?></textarea>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                       <div class="table-responsive"> 
                                        

                                        <table class="table table-bordered" id="dynamic_field">  
                                            <tr>
                                                <?php
                                                $i = 1;
                                                foreach ($show_po as $key) {
                                                    ?>
                                                    <th>Item</th>
                                                    <th>Description</th>
                                                    <th  class="hide">Stock</th>
                                                    <th>HSN Code</th>
                                                    <th>Qty</th>
                                                    <th>(Nos/Kg)</th>
                                                    <th>GST(%)</th>
                                                    <th class="gst">SGST</th>
                                                    <th class="gst">CGST</th>
                                                    <?php if ($key->gst_type != 'S') { ?>
                                                        <th class="igst_hide">IGST</th>
                                                    <?php } ?>
                                                    <th>Price</th>
                                                    <th class="hide">Discount(%)</th>
                                                    <th>Amount</th>
                                                    <th>Action</th>
                                                    <?php
                                                    $i++;
                                                    break;
                                                }
                                                ?>
                                            </tr>

                                            <?php
                                            $i = 1;
                                            foreach ($show_po as $key) {
                                                ?>
                                                <tr> 
                                                    <td>
                                                        
                                                        
                                                         <select style="width: 150px" class="form-control input-sm product_name_auto item_search_name name_list"  name="term[]" id="item_name<?php echo $i; ?>" onchange="myFunction1(this.id)" required="" data-live-search="true">
                                                            <option></option>
                                                            <?php
                                                            foreach ($item_name as $row) {
                                                                ?>
                                                                <option value="<?php echo $row->code ?>"  
                                                                <?php
                                                                if ($key->product_name == $row->code) {
                                                                    echo 'selected="selected"';
                                                                }
                                                                ?> ><?php echo $row->code; ?></option>
                                                                    <?php }
                                                                    ?>
                                                        </select>

                                                        <input type="hidden" class="form-control input-sm"   name="po_id[]" id="po_id<?php echo $i; ?>"  value="<?php echo $key->po_id; ?>"></td>
                                                    <td>
                                                        <textarea style="width: 150px"  class="form-control input-sm name_list description_auto" name="description[]" id="description<?php echo $i; ?>" rows="4"><?php echo $key->description; ?></textarea>
                                                        <!--<input type="text" name="description[]" id="description1<?php //echo $i;    ?>" value="<?php //echo $key->description;    ?>" class="form-control input-sm name_list description_auto" />-->
                                                    </td> 
                                                    <td  class="hide"> <span id="total_quantity<?php echo $i; ?>" name="total_quantity[]"></span></td>
                                                    <td><input type="text" name="hsn[]" value="<?php echo $key->hsn_code; ?>" id="hsn<?php echo $i; ?>" required="" class="form-control input-sm name_list" /></td> 
                                                    <td><input type="text" min="1" name="quantity[]" value="<?php echo $key->quantity; ?>" id="quantity<?php echo $i; ?>" required="" class="form-control input-sm name_list quantity_auto" value="1"/></td> 
                                                    <td><input type="text" name="unit[]" value="<?php echo $key->unit; ?>" id="unit<?php echo $i; ?>" class="form-control input-sm name_list" /></td>       
                                                    <td><input type="text" readonly="" name="gst_per[]" value="<?php echo $key->gst; ?>" id="gst_per<?php echo $i; ?>" class="form-control input-sm name_list" /></td> 

                                                    <td class="gst"><input type="text" readonly="" name="sgst[]" value="<?php echo $key->sgst; ?>"  id="sgst<?php echo $i; ?>" class="form-control input-sm sgst_list" /></td> 
                                                    <td class="gst"><input type="text" readonly="" name="cgst[]" value="<?php echo $key->cgst; ?>" id="cgst<?php echo $i; ?>" class="form-control input-sm cgst_list" /></td> 
                                                    <?php if ($key->gst_type != 'S') { ?>
                                                    <td class="igst_hide hidden"><input type="hidden" readonly="" name="igst[]" value="<?php echo $key->igst; ?>" id="igst<?php echo $i; ?>" class="form-control input-sm igst_list" /></td> 
                                                    <?php } ?>
                                                    <td><input type="text" name="price[]" value="<?php echo $key->price; ?>" id="price<?php echo $i; ?>" required="" class="form-control input-sm name_list price_auto"/></td>
                                                    <td class="hide"><input type="number" min="0" maxlength="2" name="discount[]" value="<?php echo $key->discount; ?>" id="discount<?php echo $i; ?>" class="form-control input-sm name_list discount_auto number-only-validation" value="" /></td>
                                                    <td><input type="hidden" name="amount[]" id="amount<?php echo $i; ?>" class="form-control input-sm name_list amount_auto" value="<?php echo $key->amount; ?>"/>
                                                        <input type="hidden" name="amount_temp[]" id="amount_temp<?php echo $i; ?>" class="form-control input-sm name_list amount_auto" value="<?php echo $key->price * $key->quantity; ?>"/>
                                                        <input type="hidden" name="gst_amount[]" id="gst_amount<?php echo $i; ?>" class="form-control input-sm name_list gst_amount_auto" value="0.00" />
                                                        <span id="span_amount<?php echo $i; ?>" name="span_amount[]">₹<?php echo $key->amount; ?></span>
                                                    </td>
                                                    <td>
                                                        <?php if ($i == 1) { ?>
                                                            <?php if ($key->gst_type != 'S') { ?>
                                                                <input type="hidden" name="igst_hide" value="igst_hide" id="igst_hide">
                                                                <input type="hidden" name="igst_check" value="igst" id="igst_check">
                                                                <button type="button" name="edit_invoice" id="edit_gst_invoice1" class="btn btn-success"><i class="fa fa-plus-circle" aria-hidden="true"></i></button> 
                                                            <?php } else if ($key->gst_type != 'I') { ?>
                                                                <input type="hidden" name="gst" value="gst" id="gst">
                                                                <input type="hidden" name="edit_sgst_cgst_check" value="edit_sgst_cgst_check" id="edit_sgst_cgst_check">
                                                                <input type="hidden" name="gst_discount_check" value="gst" id="gst_discount_check">
                                                                <button type="button" accesskey="n"  name="edit_gst_invoice1" id="edit_gst_invoice1" class="btn btn-success"><i class="fa fa-plus-circle" aria-hidden="true"></i></button> 
                                                            <?php } ?>

                                                        <?php } else { ?>
                                                            <button type="button" name="remove" id="remove<?php echo $i; ?>" class="btn btn-danger btn_remove_po">X</button>  
                                                        <?php } ?>
                                                    </td> 
                                                </tr>  
                                                <?php
                                                $i++;
                                            }
                                            ?>

                                        </table>  
                                        <div align="center">
                                            <button type="submit" name="submit" id="submit"  class="btn btn-success">Save</button>
                                        </div>
                                        <div align="right" style="margin: 10px">
                                            <span id="total_amount" name="total_amount[]" class="total_span_auto_amount">Total: ₹0.00</span><br>
                                            <span class="gst" id="sgst_amount" name="sgst_amount[]">SGST Amount: ₹0.00</span><br>
                                            <span class="gst" id="cgst_amount" name="cgst_amount[]">CGST Amount: ₹0.00</span><br>
                                            <span class="igst_hide" id="igst_amount" name="igst_amount[]">IGST Amount: ₹0.00</span><br>
                                            <span id="grand_total_amount"><b>Grand Total:</b> ₹0.00</span><br>
                                            <b> Amount in Words:<span id="word2" name="word2"></span>Only.</b><br>
                                            <input type="hidden" name="total_quotation_amount" id="total_quotation_amount" class="form-control input-sm name_list" value="0.00" />
                                        </div>
                                    </div>  
                                  
                                    
                                    
                                     <div class="row">
                                        <div class="col-xs-6">
                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-2 control-label">Terms & Conditions</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" name="po_terms_and_conditions" id="po_terms_and_conditions" rows="3"><?php echo $po_data_group['po_terms_and_conditions']; ?></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-2 control-label">Payment Terms</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" name="po_payment_terms" id="po_payment_terms" rows="3"><?php echo $po_data_group['po_payment_terms']; ?></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-2 control-label">Process Schedule</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" name="po_process_schedule" id="po_process_schedule" rows="3"><?php echo $po_data_group['po_process_schedule']; ?></textarea>
                                                </div>
                                            </div>
                                        </div>  

                                        <div class="col-xs-6">

                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-2 control-label">Taxes</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" name="po_taxes" id="po_taxes" rows="3"><?php echo $po_data_group['po_taxes']; ?></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-2 control-label">Exclusions</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" name="po_exclusions" id="po_exclusions" rows="3"><?php echo $po_data_group['po_exclusions']; ?></textarea>
                                                </div>
                                            </div>  
                                            <div class="form-group row">
                                                <label for="inputEmail3" class="col-sm-2 control-label">Note</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" name="po_note" id="po_note" rows="3"><?php echo $po_data_group['po_note']; ?></textarea>
                                                </div>
                                            </div>    
                                        </div>
                                    </div>
                                </form>  

                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <?php $this->load->view('admin/footer'); ?>
        <div class="control-sidebar-bg"></div>
    </div>
    <!-- ./wrapper -->
    
    <script>

        $(document).ready(function () {

            var igst_hide = $("#igst_hide").val();
            //alert(igst_hide);
            if (igst_hide == "igst_hide") {
                $(".gst").hide();
                $(".igst_hide").show();
            } else {
                $(".gst").show();
                $(".igst").hide();
            }

        });
    </script>
    
    
    
    
    <script>
         
        CKEDITOR.replace('po_note');    
        CKEDITOR.replace('po_terms_and_conditions');
        CKEDITOR.replace('po_payment_terms');
        CKEDITOR.replace('po_process_schedule');
        CKEDITOR.replace('po_taxes');
        CKEDITOR.replace('po_exclusions');  
    
    </script>

      <script>
    $( '.description_auto' ).each( function() {
        CKEDITOR.replace( this );
    } );
    </script>
    