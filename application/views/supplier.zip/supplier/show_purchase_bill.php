<?php
$session_data_head1 = $this->session->userdata('session_data_head');
if (isset($session_data_head1)) {
    
} else {
    header($this->config->item('header'));
}
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <!--                <h1>
                                    Purchase Bill
                                </h1>-->
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url() . 'Home/index/'?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">Purchase Bill</a></li>
                    <li class="active">Purchase Bill Details</li>
                </ol>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <label for="inputEmail3" name="number" id="number" class="col-sm-12 control-label"><h2> Purchase Bill:<?php echo $purchase_bill_data_group['number']; ?></h2></label>

                        <div class="row" style="padding:2%;">
                            <div class="pull-left">
                                    <div class="col-md-1">
                                        <a href="<?php echo base_url(); ?>SupplierController/edit_purchase_bill_details/<?php echo $purchase_bill_data_group['number']; ?>" class="btn btn-primary" role="button">Edit</a>
                                    </div>

                                <div class="pull-right">
                                   
                                    <div class="col-md-3 dropdown">
                                        <div class="dropdown">
                                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Send <b class="caret"></b>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <li><a class="dropdown-item" href="#">Send Bill</a></li>
                                                <li class="divider"></li>
                                                <li>Send Using</li>
                                                <li><a class="dropdown-item" href="https://www.gmail.com"><img src="<?php echo base_url();?>uploads/gmail.jpg" class="send-icon" alt="Gmail" style="width:29px;height: 18px;">Gmail</a></li>
                                                <li><a class="dropdown-item" href="https://login.yahoo.com"><img src="<?php echo base_url();?>uploads/yahoo.jpg" class="send-icon" alt="Yahoo Mail" style="width:29px;height: 31px;">Yahoo! Mail</a></li>
                                                <li><a class="dropdown-item" href="https://outlook.live.com/owa/?authRedirect=true"><img src="<?php echo base_url();?>uploads/hotmail.jpg" class="send-icon" alt="Outlook" style="width:29px;height: 31px;">Outlook</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-1"></div>
                                    <div class="col-md-1 dropdown">

                                        <div class="dropdown">
                                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                More <b class="caret"></b>
                                            </button>
                                            <input type="hidden" class="form-control input-sm"  name="number" id="number" required="" value="<?php echo $purchase_bill_data_group['number']; ?>">  
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <li class="hide"><a class="dropdown-item" href="<?php echo base_url(); ?>/LoginController/get_settings">Edit Business Information</a></li>
                                                <li><a class="dropdown-item" id="exportpdf" href="<?php echo base_url(); ?>Pdf/download_purchase_bill/<?php echo $purchase_bill_data_group['number']; ?>">Export as pdf</a></li>
                                               
                                            </ul>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                </div>   
                                </div>
                            </div>
                        </div>

                        <!-- /.box-header -->
                        <div class="shadows1">
                            <div class="row">
                                <section>
                                    <div class="col-md-6">
                                        <div>
                                            <img src="<?php echo base_url() . $settings['company_logo'] ?>" width="30%" height="30%">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="contemporary-template__header__info">
                                            <div class="wv-heading--title"><h1>Purchase Bill</h1></div>
                                            <div class="wv-heading--subtitle"></div>
                                            <span class="wv-text--strong"><b> <?php echo $settings['company_name']; ?></b></span><br>
                                            <span class="wv-text--strong"><b>GST Number :</b> <?php echo $settings['company_gst']; ?></span><br>
                                           <span class="wv-text--strong"><b>PAN Number :</b> <?php echo $settings['company_pan']; ?></span><br>
                                            <span class="wv-text--strong"><b>Mobile Number :</b> <?php echo $settings['mobile']; ?></span><br>
                                            <span class="wv-text--strong"><b>Email ID :</b> <?php echo $settings['email']; ?></span><br>
                                            <span class="wv-text--strong"><b>Address :</b> <?php echo $settings['address']; ?></span>
                                            
                                        </div>
                                    </div>
                                </section>

                            </div>
                            <hr>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="contemporary-template__header__info">
                                        <span class="wv-text--strong"><b>Vendor Name :</b> <?php echo $purchase_bill_data_group['company_name']; ?></b></span><br>
                                            <span class="wv-text--strong"><b>Address :</b> <?php echo $purchase_bill_data_group['address']; ?></span><br>
                                            
                                           <span class="wv-text--strong"><b>GST Number :</b> <?php if ($purchase_bill_data_group['gst']) { ?>
                                                <?php echo $purchase_bill_data_group['gst']; ?>
                                            <?php } else { ?>
                                                <?php echo "None Provided";
                                            } ?></span><br>
                                            <span class="wv-text--strong"><b>PAN Number :</b> <?php if ($purchase_bill_data_group['pancard']) { ?>
                                                <?php echo $purchase_bill_data_group['pancard']; ?>
                                            <?php } else { ?>
                                                <?php echo "None Provided";
                                            } ?></span><br>
                                            <span class="wv-text--strong"><b> KIND ATTN :</b> <?php echo $purchase_bill_data_group['fullname']; ?></span><br>
                                            
                                        </div>
                                    </div>

                                <div class="col-md-6">
                                    <span class="wv-text--strong"><b>Bill Details</b></b></span><br>
                                    
                                    
                                    <div class="contemporary-template__header__info">
                                        
                                        <span class="wv-text--strong"><b>Bill Number :</b> <?php echo $purchase_bill_data_group['number']; ?></span><br>
                                        <span class="wv-text--strong"><b>Bill Date :</b> <?php echo date('d-m-Y', strtotime($purchase_bill_data_group['date'])); ?></span><br>
                                        <span class="wv-text--strong"><b>Delivery Date :</b> <?php echo $purchase_bill_data_group['delivery_date']; ?></span><br>
                                        <span class="wv-text--strong"><b>Invoice No :</b> <?php echo $purchase_bill_data_group['invoice_no']; ?></span><br>
                                    </div>
                                    

                                </div>
                            </div>
                            <br>
                             <div class="table-responsive">  

                        <table class="table table-bordered" id="dynamic_field">  
                            <tr>
                                <th>Sr.No.</th>
                                <th>Description</th>
                                <th>HSN Code</th>
                                <th>Qty</th>
                                <th>Unit(no./kgs)</th>
                                <th>GST(%)</th>
                                <th class="gst">SGST</th>
                                <th class="gst">CGST</th>
                                <th class="igst">IGST</th>
                                <th>Price</th>
    <!--                                <th>Discount(%)</th>-->
                                <th>Amount</th>
                            </tr>
                            <?php
                            $i = 1;
                            $sgst_total_amt = 0;
                            $igst_total_amt = 0;
                            $amt = 0;
                            foreach ($show_purchase_bill as $key) {
                                ?>
                                <?php $sgst_total_amt = $sgst_total_amt + $key->cgst; ?>
                                <?php $igst_total_amt = $igst_total_amt + $key->igst; ?>
                                <tr> 
                                    <td><span id="" class=""></span>
                                        <?php echo $i; ?>
                                    </td>

                                    <td><span id="" class=""></span>
                                        <b><?php echo $key->product_name; ?></b>
                                        <?php echo $key->description; ?>
                                              <input type="hidden" name="term[]" value="<?php echo $key->product_name; ?>" id="item_name<?php echo $i; ?>" class="form-control input-sm name_list product_name_auto" />
                                    </td>

                                    <td><span id="" class=""></span>
                                        <?php echo $key->hsn_code; ?><input type="hidden" name="hsn[]" value="<?php echo $key->hsn_code; ?>" id="hsn<?php echo $i; ?>" class="form-control input-sm name_list" /> 
                                    </td>

                                    <td><span id="" class=""></span>
                                        <?php echo number_format($key->quantity, 2); ?><input type="hidden" name="quantity[]" value="<?php echo $key->quantity; ?>" id="quantity<?php echo $i; ?>" class="form-control input-sm name_list quantity_auto" value="1" />
                                    </td>
                                    
                                     <td><span id="" class=""></span>
                                        <?php echo $key->unit; ?><input type="hidden" name="unit[]" value="<?php echo $key->unit; ?>" id="unit<?php echo $i; ?>" class="form-control input-sm name_list" /> 
                                    </td>
                                    
                                    <td><span id="" class=""></span>
                                        <?php echo $key->gst; ?><input type="hidden" name="gst_per[]" value="<?php echo $key->gst; ?>" id="gst_per<?php echo $i; ?>" class="form-control input-sm name_list" />
                                    </td>

                                    <?php if ($key->gst_type != 'I') { ?>
                                        <td class="gst"><span id="" class=""></span>
                                            <input type="hidden" name="gst" value="gst" id="gst">
                                            <?php echo number_format($key->sgst, 2); ?><input type="hidden" name="sgst[]" value="<?php echo $key->sgst; ?>"  id="sgst<?php echo $i; ?>" class="form-control input-sm sgst_list" />
                                        </td>

                                        <td class="gst"><span id="" class=""></span>
                                            <?php echo number_format($key->cgst, 2); ?><input type="hidden" name="cgst[]" value="<?php echo $key->cgst; ?>" id="cgst<?php echo $i; ?>" class="form-control input-sm cgst_list" />
                                        </td>
                                    <?php } else { ?>

                                        <td class="igst">
                                            <span id="" class=""></span><?php echo number_format($key->igst, 2); ?>
                                            <input type="hidden" name="igst" value="igst" id="igst">
                                            <input type="hidden" name="igst[]" value="<?php echo $key->igst; ?>" id="igst<?php echo $i; ?>" class="form-control input-sm igst_list" />
                                        </td>
                                    <?php } ?>



                                    <td><span id="" class=""></span>
                                        <?php echo number_format($key->price, 2); ?><input type="hidden" name="price[]" value="<?php echo $key->price; ?>" id="price<?php echo $i; ?>" class="form-control input-sm name_list"/>

                                    </td>





                                    <td><span id="" class=""></span>
                                        <?php echo number_format($key->amount, 2); 
                                        $amt += $key->amount;$amt
                                        ?><input type="hidden" name="amount[]" id="amount<?php echo $i; ?>" class="form-control input-sm name_list amount_auto" value="<?php echo $key->amount; ?>"/>

                                    </td>


                                </tr>  

                                <?php
                                $i++;
                            }
                            ?>
                            <?php
                            $i = 1;
                            foreach ($show_purchase_bill as $key) {
                                ?>
                                <?php if ($key->gst_type != 'I') { ?>

                                    <tr class="">
                                            <td colspan="9"  class="text-right">
                                                Total before tax: 
                                            </td>
                                            <td colspan="1"  class="text-left">
                                                ₹ <?php echo $amt; ?>
                                            </td>
                                            
                             </tr> 
                                    <tr>
                                        <td colspan="9"  class="text-right">
                                            <label class="control-label"><b>CGST Amount : </b></label>
                                        </td>

                                        <td colspan="1"  class="text-left">
                                            <b><?php echo number_format($sgst_total_amt, 2); ?></b><br>
                                        </td>

                                    </tr>

                                    <tr>
                                        <td colspan="9"  class="text-right">
                                            <label class="control-label"><b>SGST Amount : </b></label>
                                        </td>
                                        <td colspan="1"  class="text-left">
                                            <b><?php echo number_format($sgst_total_amt, 2); ?></b><br>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td colspan="9"  class="text-right">
                                            <label class="control-label"><b>GST Amount : </b></label>
                                        </td>
                                        <td colspan="1"  class="text-left">
                                            <b><?php echo number_format($sgst_total_amt * 2, 2); ?></b><br>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td colspan="9"  class="text-right">
                                            <label class="control-label"><b>Grand Total (INR) : </b></label>
                                        </td>
                                        <td colspan="1"  class="text-left">
                                            <b>₹<?php echo number_format($purchase_bill_data_group['total'], 2); ?></b> <br>
                                        </td>
                                    </tr>
                                    <tr></tr>

                                    <tr>
                                        <td colspan="10"  class="text-right">
                                            <?php
                                            // include amount_convert
                                            require( APPPATH . '/third_party/amount_convert.php');
                                            ?>
                                            <b> Amount in Words:<?php echo number_to_word($purchase_bill_data_group['total']); ?> Only.</b><br>
                                        </td>
                                    </tr>

                                <?php } else { ?>
                                    
                                     <tr class="">
                                            <td colspan="7"  class="text-right">
                                                Total before tax: 
                                            </td>
                                            <td colspan="1"  class="text-left">
                                                ₹ <?php echo $amt; ?>
                                            </td>
                                            
                             </tr> 

                                    <tr>
                                        <td colspan="7"  class="text-right">
                                            <label class="control-label"><b>IGST Amount : </b></label>
                                        </td>

                                        <td colspan="1"  class="text-left">
                                            <b> <?php echo number_format($igst_total_amt, 2); ?></b><br>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td colspan="7"  class="text-right">
                                            <label class="control-label"><b>Grand Total (INR) : </b></label>
                                        </td>

                                        <td colspan="1"  class="text-left">
                                            <b>₹<?php echo number_format($purchase_bill_data_group['total'], 2); ?></b> <br>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td colspan="9"  class="text-right">
                                            <?php
                                            // include amount_convert
                                            require( APPPATH . '/third_party/amount_convert.php');
                                            ?>
                                            <b> Amount in Words:<?php echo number_to_word($purchase_bill_data_group['total']); ?> Only.</b><br>
                                        </td>
                                    </tr>

                                    <tr>

                                    </tr>
                                <?php } ?>

                                <?php
                                $i++;
                                break;
                            }
                            ?>
                        </table>   

                       

                        <div class="col-sm-12">
                            <textarea style="overflow: auto;
                                      border: none;" class="form-control" readonly="" name="notes" id="quotation_memo" rows="8"><?php echo $settings['invoice_notes']; ?></textarea>
                        </div>
                        <div class="form-group row ">
                            <label for="inputEmail3" class="col-sm-9 control-label"><b>Receivers Signatory :</b></label>
                            <label for="inputEmail3" class="col-sm-3 control-label"><b> Authorized Signatory :</b></label>
                        </div>

                        <div style="text-align: center;">This is Computer Generated Invoice</div><br>

                    </div>  
                        </div>
                        <!-- /.box-body -->
                        <!-- /.box -->
                    </div>
                    <!-- /.col -->
                </div>
            </section>
        </div>
        <!-- /.row -->
        <?php $this->load->view('admin/footer'); ?>
        <div class="control-sidebar-bg"></div>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    
    
        <script>

        $(document).ready(function () {

            var igst = $("#igst").val();
         //   alert(igst);
            if (igst == "igst") {
                $(".gst").hide();
                $(".igst").show();

            } else {
                $(".gst").show();
//                 $(".gst"). css('padding','10% 0% 0% 0%')
                $(".igst").hide();
            }

        });
    </script>





