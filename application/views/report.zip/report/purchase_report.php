<?php

//echo 'sdfsdsd';die();
// include PHPExcel
require( APPPATH . '/third_party/Classes/PHPExcel.php');

// create new PHPExcel object
$objPHPExcel = new PHPExcel;
// set default font
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
// set default font size
$objPHPExcel->getDefaultStyle()->getFont()->setSize(8);
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");

/**
 * Define currency and number format.
 */
// currency format, € with < 0 being in red color
$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
// number format, with thousands separator and two decimal points.
$numberFormat = '#,#0.##;[Red]-#,#0.##';

// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Excel report');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:T1')->getFont()->setBold(true)->setSize(16);
$objPHPExcel->getActiveSheet()
        ->getStyle('A1:T1')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("31a3dd");


$styleArray = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => '000000'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);
$styleArray1 = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => 'FFFFFF'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);

$objPHPExcel->getActiveSheet()->getStyle('A1:T1')->applyFromArray($styleArray1);
$objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('H2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('I2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('J2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('K2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('L2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('M2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('N2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('O2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('P2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('Q2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('R2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('S2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('T2')->applyFromArray($styleArray);


$objPHPExcel->setActiveSheetIndex(0);
// write header
$objPHPExcel->getActiveSheet()->mergeCells('A1:T1');

$objPHPExcel->getActiveSheet()->getCell('A1')->setValue('Purchase Report')->getStyle('A1:T1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

$objPHPExcel->getActiveSheet()->SetCellValue('A2', 'Sr.No.');
$objPHPExcel->getActiveSheet()->SetCellValue('B2', 'PO No');
$objPHPExcel->getActiveSheet()->SetCellValue('C2', 'Company Name');
$objPHPExcel->getActiveSheet()->SetCellValue('D2', 'PO Date');
$objPHPExcel->getActiveSheet()->SetCellValue('E2', 'Type');

$objPHPExcel->getActiveSheet()->SetCellValue('F2', 'Total Before Tax');

$objPHPExcel->getActiveSheet()->SetCellValue('G2', 'SGST');
$objPHPExcel->getActiveSheet()->SetCellValue('H2', 'CGST');
$objPHPExcel->getActiveSheet()->SetCellValue('I2', 'IGST');
$objPHPExcel->getActiveSheet()->SetCellValue('J2', 'Total GST');

$objPHPExcel->getActiveSheet()->SetCellValue('K2', 'Grand Total');

$objPHPExcel->getActiveSheet()->SetCellValue('L2', 'Balance');
$objPHPExcel->getActiveSheet()->SetCellValue('M2', 'Payment Due Date');

$objPHPExcel->getActiveSheet()->SetCellValue('N2', 'PO Date');
$objPHPExcel->getActiveSheet()->SetCellValue('O2', 'Vendor Name');
$objPHPExcel->getActiveSheet()->SetCellValue('P2', 'Pan Number');
$objPHPExcel->getActiveSheet()->SetCellValue('Q2', 'GST Number');
$objPHPExcel->getActiveSheet()->SetCellValue('R2', 'Email');
$objPHPExcel->getActiveSheet()->SetCellValue('S2', 'Mobile');
$objPHPExcel->getActiveSheet()->SetCellValue('T2', 'Address');


$rowCount = 3;
$rowCou = 1;

foreach ($result as $row) {

    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $rowCou);
    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $row->number);
    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $row->company_name);
    $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, date("d-m-Y",strtotime($row->purchase_date)));
   
    $gst_type = '';
     if ($row->gst_type != 'I') { 
                                                         $gst_type = 'SGST';
                                                     } else { 
                                                         $gst_type = 'IGST';
                                                     } 
    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $gst_type);
    $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $row->total_before_tax);
    $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $row->sgst);
    $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $row->cgst);
    $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $row->igst);
    
    $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $row->total_gst_amount);
    $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $row->total);
    $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $row->balance);
    $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowCount, $row->payment_due_date);
    
    $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowCount, $row->delivery_date);
    $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowCount, $row->fullname);
    $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowCount, $row->pancard);
    $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowCount, $row->customer_gst);
    $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowCount, $row->email);
    $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowCount, $row->mobile);
    $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowCount, $row->address);
   
   
$rowCou++;
    $rowCount++;
}
//echo 'test';die();
$lTotalVar = 'E' . $rowCount;

$kTotalVar = 'F' . $rowCount;

$eTotalVar = 'G' . $rowCount;

$eTotalVar1 = 'H' . $rowCount;

$eTotalVar2 = 'I' . $rowCount;

$eTotalVar3 = 'J' . $rowCount;

$eTotalVar4 = 'K' . $rowCount;

$eTotalVar5 = 'L' . $rowCount;



$makeBOLDVar = $lTotalVar;

$objSheet->getStyle($makeBOLDVar)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($makeBOLDVar)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");

$objSheet->getStyle($kTotalVar)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($kTotalVar)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");



$objSheet->getStyle($eTotalVar)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($eTotalVar)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");

$objSheet->getStyle($eTotalVar1)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($eTotalVar1)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");

$objSheet->getStyle($eTotalVar2)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($eTotalVar2)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");


$objSheet->getStyle($eTotalVar3)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($eTotalVar3)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");


$objSheet->getStyle($eTotalVar4)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($eTotalVar4)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");

$objSheet->getStyle($eTotalVar5)->getFont()->setBold(true)->setSize(14);

$objPHPExcel->getActiveSheet()
        ->getStyle($eTotalVar5)
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");



 
 $objPHPExcel->getActiveSheet()->setCellValue($lTotalVar, 'Total:');
 $objPHPExcel->getActiveSheet()->setCellValue($kTotalVar, 'Total:');
 
 $rowc =  $rowCount-1;
 $iTotalPOamt = "=SUM(F2:F". $rowc . ")";
 $iTotalVar = 'F' . $rowCount;
 $objPHPExcel->getActiveSheet()->setCellValue($iTotalVar, $iTotalPOamt);
 
 
  $iTotalbalamt = "=SUM(G2:G". $rowc . ")";
 $iTotalBalVar = 'G' . $rowCount;
 $objPHPExcel->getActiveSheet()->setCellValue($iTotalBalVar, $iTotalbalamt);
 
$iTotalbalamt1 = "=SUM(H2:H". $rowc . ")";
 $iTotalBalVar1 = 'H' . $rowCount;
 $objPHPExcel->getActiveSheet()->setCellValue($iTotalBalVar1, $iTotalbalamt1);
 
 $iTotalbalamt2 = "=SUM(I2:I". $rowc . ")";
 $iTotalBalVar2 = 'I' . $rowCount;
 $objPHPExcel->getActiveSheet()->setCellValue($iTotalBalVar2, $iTotalbalamt2);
 
 $iTotalbalamt3 = "=SUM(J2:J". $rowc . ")";
 $iTotalBalVar3 = 'J' . $rowCount;
 $objPHPExcel->getActiveSheet()->setCellValue($iTotalBalVar3, $iTotalbalamt3);
 
 
 $iTotalbalamt4 = "=SUM(K2:K". $rowc . ")";
 $iTotalBalVar4 = 'K' . $rowCount;
 $objPHPExcel->getActiveSheet()->setCellValue($iTotalBalVar4, $iTotalbalamt4);
 
 $iTotalbalamt5 = "=SUM(L2:L". $rowc . ")";
 $iTotalBalVar5 = 'L' . $rowCount;
 $objPHPExcel->getActiveSheet()->setCellValue($iTotalBalVar5, $iTotalbalamt5);
 
 
 
// autosize the columns
$objSheet->getColumnDimension('A')->setAutoSize(true);
$objSheet->getColumnDimension('B')->setAutoSize(true);
$objSheet->getColumnDimension('C')->setAutoSize(true);
$objSheet->getColumnDimension('D')->setAutoSize(true);
$objSheet->getColumnDimension('E')->setAutoSize(true);
$objSheet->getColumnDimension('F')->setAutoSize(true);
$objSheet->getColumnDimension('G')->setAutoSize(true);
$objSheet->getColumnDimension('H')->setAutoSize(true);
$objSheet->getColumnDimension('I')->setAutoSize(true);
$objSheet->getColumnDimension('J')->setAutoSize(true);
$objSheet->getColumnDimension('K')->setAutoSize(true);
$objSheet->getColumnDimension('L')->setAutoSize(true);
$objSheet->getColumnDimension('M')->setAutoSize(true);
$objSheet->getColumnDimension('N')->setAutoSize(true);
$objSheet->getColumnDimension('O')->setAutoSize(true);
$objSheet->getColumnDimension('P')->setAutoSize(true);
$objSheet->getColumnDimension('Q')->setAutoSize(true);
$objSheet->getColumnDimension('R')->setAutoSize(true);
$objSheet->getColumnDimension('S')->setAutoSize(true);
$objSheet->getColumnDimension('T')->setAutoSize(true);



// write the file to excel
// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
$file_name = 'Purchase Report' . '_' . $from_date . '_' . $to_date. '.xlsx';

header('Content-Disposition: attachment;filename="'. $file_name .'"');
$objWriter->save('php://output');
exit;







?>