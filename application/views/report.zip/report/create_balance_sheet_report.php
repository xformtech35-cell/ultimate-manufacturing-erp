<?php

$session_data_head1 = $this->session->userdata('session_data_head');
if (isset($session_data_head1)) {
    
} else {
    header($this->config->item('header'));
}
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                  Balance Sheet Report
                </h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url() . 'Home/index/' ?>"><i class="fa fa-dashboard"></i>Home</a></li>
                    <li><a href="#">Report</a></li>
                    <li class="active">Report</li>
                </ol>
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- Horizontal Form -->
                        <div class="box box-info">
                            <div class="box-header with-border">
                                <h3 class="box-title">Balance Sheet Report </h3>
                            </div>
                            <!-- /.box-header -->
                            <!-- form start -->
                            <form class="form-horizontal form_overlay" method="post" action="<?php echo base_url(); ?>ReportController/get_balance_sheet_report">
                                <div class="box-body">
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-3 control-label">From Date<span style="color: red;">*</span></label>
                                        <div class="col-sm-4">
                                            <input type="text" id="from_date" autocomplete="off" class="form-control backdate created-date" name="from_date" required="" onkeydown="return false;">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-3 control-label">To Date<span style="color: red;">*</span></label>
                                        <div class="col-sm-4">
                                            <input type="text" id="to_date" autocomplete="off" class="form-control  payment-due-date-check" name="to_date" required="" onkeydown="return false;"> 
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-3 control-label">Assets</label>
                                        <div class="col-sm-9">
                                            <div style="overflow-x:auto;">
                                                <table class="table-bordered" id="dynamic_field">
                                                    <tr>
                                                        <td style="width: 120px">
                                                            
                                                            
                                                            <select class="form-control input-sm asset"  name="asset[]" id="asset" data-live-search="true">
                                                        <option value=""></option>
                                                        <?php foreach ($asset_sub_category as $key) { ?>
                                                            <option value="<?php echo $key->asset; ?>"><?php echo $key->asset; ?></option> 
                                                        <?php } ?>  
                                                    </select>
                                                        </td>
                                                        <td style="width: 120px">
                                                            <select class="form-control input-sm asset"  name="asset_sub_category[]" id="asset_sub_category" data-live-search="true">
                                                        <option value=""></option>
                                                        <?php foreach ($asset_sub_category as $key) { ?>
                                                            <option value="<?php echo $key->asset_sub_category; ?>"><?php echo $key->asset_sub_category; ?></option> 
                                                        <?php } ?>  
                                                    </select>
                                                        </td> 
                                                        <td style="width: 120px"><input type="text" name="price[]" id="price1" class="form-control form-control-sm "/></td> 
                                                        <td><button type="button" accesskey="n" name="add_assets" id="add_assets" class="btn btn-success"><i class="fa fa-plus-circle" aria-hidden="true"></i></button></td>  
                                                    </tr>
                                                </table>
                                                
                                                
                                                 
                                            </div>
                                        </div>
                                    </div>
                                    <center><button type="submit" class="btn btn-default">Cancel</button>
                                        <button type="submit" class="btn btn-success">Submit</button></center>
                                </div>
                                <!-- /.box-body -->
                                <div class="box-footer">
                                    
                                </div>
                                <!-- /.box-footer -->
                            </form>
                            
                             <a href="<?php echo base_url(); ?>ReportController/get_sales_report_by_date_xlsx"><button class="btn btn-success pull-right">Export to Excel</button></a>
                            <table id="example3" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Invoice Number</th>
                                        <th>Date</th>
                                        <th>Total</th>
                                        <th>Balance</th>
                                        <th>Payment Due Date</th>
                                        <th>Customer Po</th>
                                        <th>PO Date</th>
                                        <th>Company Name</th>
                                        <th>Customer Name</th>
                                        <th>GST Number</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Address</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    
                                    
                                    
                                    
                                </tbody>
                            </table>
                            
                            
                        </div>
                        <!-- /.box -->
                    </div>
                 </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>

        <?php $this->load->view('admin/footer'); ?>
        <div class="control-sidebar-bg"></div>
    </div>
    <!-- ./wrapper -->

