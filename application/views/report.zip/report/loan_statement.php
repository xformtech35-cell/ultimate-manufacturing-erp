<?php

// include PHPExcel
require( APPPATH . '/third_party/Classes/PHPExcel.php');

// create new PHPExcel object
$objPHPExcel = new PHPExcel;
// set default font
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
// set default font size
$objPHPExcel->getDefaultStyle()->getFont()->setSize(8);
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");

/**
 * Define currency and number format.
 */
// currency format, € with < 0 being in red color
$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
// number format, with thousands separator and two decimal points.
$numberFormat = '#,#0.##;[Red]-#,#0.##';

// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Excel report');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:E1')->getFont()->setBold(true)->setSize(16);
$objPHPExcel->getActiveSheet()
        ->getStyle('A1:E1')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("31a3dd");


$styleArray = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => '000000'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);
$styleArray1 = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => 'FFFFFF'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);

$objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($styleArray1);
$objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray($styleArray);
$objPHPExcel->setActiveSheetIndex(0);
// write header
$objPHPExcel->getActiveSheet()->mergeCells('A1:E1');

$objPHPExcel->getActiveSheet()->getCell('A1')->setValue('Loan Report')->getStyle('A1:E1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

$objPHPExcel->getActiveSheet()->SetCellValue('A2', 'Sr.No.');
$objPHPExcel->getActiveSheet()->SetCellValue('B2', 'Date');
$objPHPExcel->getActiveSheet()->SetCellValue('C2', 'Interest Rate');
$objPHPExcel->getActiveSheet()->SetCellValue('D2', 'Amount');
$objPHPExcel->getActiveSheet()->SetCellValue('E2', 'Ending Balance');



$rowCount = 3;
$rowCou = 1;
foreach ($loan_report as $row) {
//    var_dump($loan_report);
//    die();
    //$str = str_replace("./uploads/", "", $row->qo_file_path);
//    if($row->net_amount==0 && $row->expense>0){
//        $margin = $row->total - $row->expense;
//    }else{
//        $margin = $row->net_amount - $row->expense;
//    }
    //echo $row->company_name; die();
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $rowCou);
    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $row->loan_date);
    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $row->interest_rate);
    $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $row->current_balance);
    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $row->current_balance);
$rowCou++;
    $rowCount++;
}

// autosize the columns
$objSheet->getColumnDimension('A')->setAutoSize(true);
$objSheet->getColumnDimension('B')->setAutoSize(true);
$objSheet->getColumnDimension('C')->setAutoSize(true);
$objSheet->getColumnDimension('D')->setAutoSize(true);
$objSheet->getColumnDimension('E')->setAutoSize(true);

// write the file to excel
// Redirect output to a client’s web browser (Excel2007)

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
$file_name = ' Loan Report' . $from_date . '' . $to_date. '.xlsx';
header('Content-Disposition: attachment;filename="'. $file_name .'"');
$objWriter->save('php://output');
exit;
