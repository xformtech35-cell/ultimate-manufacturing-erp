<?php

// include PHPExcel
require( APPPATH . '/third_party/Classes/PHPExcel.php');

// create new PHPExcel object
$objPHPExcel = new PHPExcel;
// set default font
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
// set default font size
$objPHPExcel->getDefaultStyle()->getFont()->setSize(8);
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");

/**
 * Define currency and number format.
 */
// currency format, € with < 0 being in red color
$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
// number format, with thousands separator and two decimal points.
$numberFormat = '#,#0.##;[Red]-#,#0.##';

// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Excel report');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:G1')->getFont()->setBold(true)->setSize(16);
$objPHPExcel->getActiveSheet()
        ->getStyle('A1:G1')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("31a3dd");


$styleArray = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => '000000'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);
$styleArray1 = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => 'FFFFFF'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);

$objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($styleArray1);
$objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray($styleArray);


$objPHPExcel->setActiveSheetIndex(0);
// write header
$objPHPExcel->getActiveSheet()->mergeCells('A1:G1');

$objPHPExcel->getActiveSheet()->getCell('A1')->setValue('Expenditure Report')->getStyle('A1:G1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

$objPHPExcel->getActiveSheet()->SetCellValue('A2', 'Sr.No.');
$objPHPExcel->getActiveSheet()->SetCellValue('B2', 'Amount');
$objPHPExcel->getActiveSheet()->SetCellValue('C2', 'Note');
$objPHPExcel->getActiveSheet()->SetCellValue('D2', 'Date');
$objPHPExcel->getActiveSheet()->SetCellValue('E2', 'Category');
$objPHPExcel->getActiveSheet()->SetCellValue('F2', 'Employee Name');
$objPHPExcel->getActiveSheet()->SetCellValue('G2', 'Payment Status');

$rowCount = 3;
$rowCou = 1;
foreach ($result as $row) {
    $status = '';
    
    switch ($row->status) {
        case "1":
            $status = "Done";
            break;
        case "2":
            $status = "Pending on Date";
            break;
        case "3":
            $status = "Advance";
            break;
        default:
            $status = "Pending Amount";
    }
    
    //echo $row->company_name; die();
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $rowCou);
    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $row->expense_amount);
    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $row->expense_note);
    $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $row->date);
    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $row->expense_category);
    $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $row->employee_name);
    $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $status);


    $rowCou++;
    $rowCount++;
}


// autosize the columns
$objSheet->getColumnDimension('A')->setAutoSize(true);
$objSheet->getColumnDimension('B')->setAutoSize(true);
$objSheet->getColumnDimension('C')->setAutoSize(true);
$objSheet->getColumnDimension('D')->setAutoSize(true);
$objSheet->getColumnDimension('E')->setAutoSize(true);
$objSheet->getColumnDimension('F')->setAutoSize(true);
$objSheet->getColumnDimension('G')->setAutoSize(true);


// write the file to excel
// Redirect output to a client’s web browser (Excel2007)


header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
$file_name = 'Expenditure Report'. $from_date . '' . $to_date. '.xlsx';

header('Content-Disposition: attachment;filename="'. $file_name .'"');
$objWriter->save('php://output');
exit;