<?php

// include PHPExcel
require( APPPATH . '/third_party/Classes/PHPExcel.php');

// create new PHPExcel object
$objPHPExcel = new PHPExcel;
// set default font
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
// set default font size
$objPHPExcel->getDefaultStyle()->getFont()->setSize(8);
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");

/**
 * Define currency and number format.
 */
// currency format, € with < 0 being in red color
$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
// number format, with thousands separator and two decimal points.
$numberFormat = '#,#0.##;[Red]-#,#0.##';

// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Excel report');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:L1')->getFont()->setBold(true)->setSize(16);
$objPHPExcel->getActiveSheet()
        ->getStyle('A1:L1')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("e8f442");


$styleArray = array(
    'font' => array(
        'bold' => true,
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);

$objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray($styleArray);


$objPHPExcel->setActiveSheetIndex(0);
// write header
$objPHPExcel->getActiveSheet()->mergeCells('A1:G1');

$objPHPExcel->getActiveSheet()->getCell('A1')->setValue('Customer Statement Report')->getStyle('A1:G1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

$objPHPExcel->getActiveSheet()->SetCellValue('A2', 'Sr.No.');
$objPHPExcel->getActiveSheet()->SetCellValue('B2', 'Date');
$objPHPExcel->getActiveSheet()->SetCellValue('C2', 'Payment Type');
$objPHPExcel->getActiveSheet()->SetCellValue('D2', 'Total');
$objPHPExcel->getActiveSheet()->SetCellValue('E2', 'Payment Amount');
$objPHPExcel->getActiveSheet()->SetCellValue('F2', 'Balance');
$objPHPExcel->getActiveSheet()->SetCellValue('G2', 'Customer Name');

$grand_total = 0;
$paid_amount = 0;
$total_payable = 0;
$rowCount = 3;
$rowCou = 1;
$company_name='';
foreach ($result as $row) {
     $grand_total = (int)$grand_total + (int)$row['total'];
    $paid_amount = (int)$paid_amount + (int)$row['invocie_pay_amount'];
    $total_payable = (int)$grand_total - (int)$paid_amount; 
    $balance='';
    
    if (isset($row['balance']))
        {
       $balance= $row['balance'];
                
        }
         if (isset($row['company_name']))
        {
       $company_name= $row['company_name'];
                
        }
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $rowCou);
    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $row['invoice_date']);
    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $row['invoice_number']);
    $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $row['total']);
    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $row['invocie_pay_amount']);
   $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $balance);
   $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $company_name);
 
$rowCou++;
    $rowCount++;
}
$objPHPExcel->getActiveSheet()->mergeCells('A'.$rowCount.':'.'C'.$rowCount);
$objPHPExcel->getActiveSheet()->getCell('A'.$rowCount)->setValue('Grand Total')->getStyle('A'.$rowCount.':'.'C'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getCell('D'.$rowCount)->setValue($grand_total)->getStyle('D'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getCell('E'.$rowCount)->setValue($paid_amount)->getStyle('E'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$rowCount = $rowCount + 1; 
$objPHPExcel->getActiveSheet()->mergeCells('A'.$rowCount.':'.'E'.$rowCount);
$objPHPExcel->getActiveSheet()->getCell('A'.$rowCount)->setValue('Total Payable')->getStyle('A'.$rowCount.':'.'C'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getCell('F'.$rowCount)->setValue($total_payable)->getStyle('F'.$rowCount)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);


// autosize the columns
$objSheet->getColumnDimension('A')->setAutoSize(true);
$objSheet->getColumnDimension('B')->setAutoSize(true);
$objSheet->getColumnDimension('C')->setAutoSize(true);
$objSheet->getColumnDimension('D')->setAutoSize(true);
$objSheet->getColumnDimension('E')->setAutoSize(true);
$objSheet->getColumnDimension('F')->setAutoSize(true);
$objSheet->getColumnDimension('G')->setAutoSize(true);

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Customer Statement Report '.$company_name.'.xlsx"');
$objWriter->save('php://output');
exit;
