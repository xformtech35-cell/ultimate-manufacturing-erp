<?php

//echo 'sdfsdsd';die();
// include PHPExcel
require( APPPATH . '/third_party/Classes/PHPExcel.php');

// create new PHPExcel object
$objPHPExcel = new PHPExcel;
// set default font
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
// set default font size
$objPHPExcel->getDefaultStyle()->getFont()->setSize(8);
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");

/**
 * Define currency and number format.
 */
// currency format, € with < 0 being in red color
$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
// number format, with thousands separator and two decimal points.
$numberFormat = '#,#0.##;[Red]-#,#0.##';

// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Excel report');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:L1')->getFont()->setBold(true)->setSize(16);
$objPHPExcel->getActiveSheet()
        ->getStyle('A1:L1')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        ->setRGB("31a3dd");


$styleArray = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => '000000'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);
$styleArray1 = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => 'FFFFFF'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);

$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->applyFromArray($styleArray1);
$objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('H2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('I2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('J2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('K2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('L2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('M2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('N2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('O2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('P2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('Q2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('R2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('S2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('T2')->applyFromArray($styleArray);
//$objPHPExcel->getActiveSheet()->getStyle('U2')->applyFromArray($styleArray);

$objPHPExcel->setActiveSheetIndex(0);
// write header
$objPHPExcel->getActiveSheet()->mergeCells('A1:L1');

$objPHPExcel->getActiveSheet()->getCell('A1')->setValue('Quotation Report')->getStyle('A1:L1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

$objPHPExcel->getActiveSheet()->SetCellValue('A2', 'Sr.No.');
$objPHPExcel->getActiveSheet()->SetCellValue('B2', 'Status');
$objPHPExcel->getActiveSheet()->SetCellValue('C2', 'Number');
$objPHPExcel->getActiveSheet()->SetCellValue('D2', 'Date');
$objPHPExcel->getActiveSheet()->SetCellValue('E2', 'Total');
$objPHPExcel->getActiveSheet()->SetCellValue('F2', 'Company Name');

$objPHPExcel->getActiveSheet()->SetCellValue('G2', 'Customer Name');

$objPHPExcel->getActiveSheet()->SetCellValue('H2', 'GST Number');
$objPHPExcel->getActiveSheet()->SetCellValue('I2', 'GST Type');
$objPHPExcel->getActiveSheet()->SetCellValue('J2', 'Email');
$objPHPExcel->getActiveSheet()->SetCellValue('K2', 'Mobile');
$objPHPExcel->getActiveSheet()->SetCellValue('L2', 'Address');
//

//

//$objPHPExcel->getActiveSheet()->SetCellValue('M2', 'Payment Due Date');
//$objPHPExcel->getActiveSheet()->SetCellValue('N2', 'Customer PO');
//$objPHPExcel->getActiveSheet()->SetCellValue('O2', 'PO Date');
//$objPHPExcel->getActiveSheet()->SetCellValue('P2', 'Customer Name');
//$objPHPExcel->getActiveSheet()->SetCellValue('Q2', 'Pan Number');
//$objPHPExcel->getActiveSheet()->SetCellValue('R2', 'GST Number');
//$objPHPExcel->getActiveSheet()->SetCellValue('S2', 'Email');
//$objPHPExcel->getActiveSheet()->SetCellValue('T2', 'Mobile');
//$objPHPExcel->getActiveSheet()->SetCellValue('U2', 'Address');


$rowCount = 3;
$rowCou = 1;
$status = '';
$type ='';

foreach ($result as $row) {
    
     if ($row->status == 1) {
                                                               $status = 'Draft';}
                                               
                                                              if ($row->status == 2){ 
                                                              $status = 'Sent';}
                                           
                                                              if ($row->status == 3){
                                                              $status = 'Viewed';}
                                            
                                                             if ($row->status == 4) {
                                                             $status = 'Approved';}
                                              
                                                             if ($row->status == 5){ 
                                                             $status = 'Rejected';}
                                           
                                                             if ($row->status == 6){ 
                                                             $status = 'Canceled' ;}
                                                             
                                                        if ($row->gst_type != 'I') {
                                                        $type = 'SGST';
                                                        }else {
                                                        $type = 'IGST';
                                                     } 
                                                             
                                                             
    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $rowCou);
    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount,  $status);
    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $row->number);
   $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, date("d-m-Y",strtotime($row->date)));
   
   
    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $row->total);
    $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $row->company_name);
    $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $row->fullname);
    $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $row->customer_gst);
     $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount,  $type);   
    
    $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $row->email);
    $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $row->mobile);
    $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $row->address);
                   
   
$rowCou++;
    $rowCount++;
}
//echo 'test';die();

 
// autosize the columns
$objSheet->getColumnDimension('A')->setAutoSize(true);
$objSheet->getColumnDimension('B')->setAutoSize(true);
$objSheet->getColumnDimension('C')->setAutoSize(true);
$objSheet->getColumnDimension('D')->setAutoSize(true);
$objSheet->getColumnDimension('E')->setAutoSize(true);
$objSheet->getColumnDimension('F')->setAutoSize(true);
$objSheet->getColumnDimension('G')->setAutoSize(true);
$objSheet->getColumnDimension('H')->setAutoSize(true);
$objSheet->getColumnDimension('I')->setAutoSize(true);
$objSheet->getColumnDimension('J')->setAutoSize(true);
$objSheet->getColumnDimension('K')->setAutoSize(true);
$objSheet->getColumnDimension('L')->setAutoSize(true);

// write the file to excel
// Redirect output to a client’s web browser (Excel2007)


header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
$file_name = 'Quotation_Report'.  '_' . $from_date . '_' . $to_date. '.xlsx';

header('Content-Disposition: attachment;filename="'. $file_name .'"');
$objWriter->save('php://output');
exit;






?>