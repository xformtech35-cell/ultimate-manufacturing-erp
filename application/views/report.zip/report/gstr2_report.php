<?php

// include PHPExcel
require( APPPATH . '/third_party/Classes/PHPExcel.php');

// create new PHPExcel object
$objPHPExcel = new PHPExcel;
// set default font
$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
// set default font size
$objPHPExcel->getDefaultStyle()->getFont()->setSize(8);
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");

/**
 * Define currency and number format.
 */
// currency format, € with < 0 being in red color
$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
// number format, with thousands separator and two decimal points.
$numberFormat = '#,#0.##;[Red]-#,#0.##';

// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Excel report');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:L1')->getFont()->setBold(true)->setSize(16);
$objPHPExcel->getActiveSheet()
        ->getStyle('A1:L1')
        ->getFill()
        ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
        ->getStartColor()
        
        ->setRGB("31a3dd");


$styleArray = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => '000000'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);

$styleArray1 = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => 'FFFFFF'),
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
    ),
    'borders' => array(
        'top' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'bottom' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'right' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
        'left' => array(
            'style' => PHPExcel_Style_Border::BORDER_THIN,
        ),
    )
);


$objPHPExcel->getActiveSheet()->getStyle('A1:L1')->applyFromArray($styleArray1);

//$objPHPExcel->getActiveSheet()->getStyle('A1:G1')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('H2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('I2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('J2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('K2')->applyFromArray($styleArray);
$objPHPExcel->getActiveSheet()->getStyle('L2')->applyFromArray($styleArray);
$objPHPExcel->setActiveSheetIndex(0);
// write header
$objPHPExcel->getActiveSheet()->mergeCells('A1:L1');

$objPHPExcel->getActiveSheet()->getCell('A1')->setValue('GSTR 2 Report')->getStyle('A1:L1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

$objPHPExcel->getActiveSheet()->SetCellValue('A2', 'Sr.No.');
$objPHPExcel->getActiveSheet()->SetCellValue('B2', 'Invoice No.');
$objPHPExcel->getActiveSheet()->SetCellValue('C2', 'Date');
$objPHPExcel->getActiveSheet()->SetCellValue('D2', 'Transaction Type');
$objPHPExcel->getActiveSheet()->SetCellValue('E2', 'GST');
$objPHPExcel->getActiveSheet()->SetCellValue('F2', 'SGST');
$objPHPExcel->getActiveSheet()->SetCellValue('G2', 'CGST');
$objPHPExcel->getActiveSheet()->SetCellValue('H2', 'IGST');
$objPHPExcel->getActiveSheet()->SetCellValue('I2', 'Invoice Amount');
$objPHPExcel->getActiveSheet()->SetCellValue('J2', 'Company Name');
$objPHPExcel->getActiveSheet()->SetCellValue('K2', 'State Code');
$objPHPExcel->getActiveSheet()->SetCellValue('L2', 'GSTIN');
$rowCount = 3;
$rowCou = 1;
foreach ($gstr2_report as $row) {

    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $rowCou);
    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $row->invoice_number);
    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $row->invoice_date);
    $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, 'Sale');
    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $row->gst);
    $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $row->sgst);
    $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $row->cgst);
    $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $row->igst);
     $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $row->amount);
    $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $row->company_name);
   $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $row->state_code);
   $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $row->gst);
// 
$rowCou++;
    $rowCount++;
}

// autosize the columns
$objSheet->getColumnDimension('A')->setAutoSize(true);
$objSheet->getColumnDimension('B')->setAutoSize(true);
$objSheet->getColumnDimension('C')->setAutoSize(true);
$objSheet->getColumnDimension('D')->setAutoSize(true);
$objSheet->getColumnDimension('E')->setAutoSize(true);
$objSheet->getColumnDimension('F')->setAutoSize(true);
$objSheet->getColumnDimension('G')->setAutoSize(true);
$objSheet->getColumnDimension('H')->setAutoSize(true);
$objSheet->getColumnDimension('I')->setAutoSize(true);
$objSheet->getColumnDimension('J')->setAutoSize(true);
$objSheet->getColumnDimension('K')->setAutoSize(true);
$objSheet->getColumnDimension('L')->setAutoSize(true);
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
$file_name = ' GSTR2 Report ' . $from_date . '' . $to_date. '.xlsx';
header('Content-Disposition: attachment;filename="'. $file_name .'"');

$objWriter->save('php://output');
exit;
