<?php
$session_data_head1 = $this->session->userdata('session_data_head');
if (isset($session_data_head1)) {
    
} else {
    header($this->config->item('header'));
}
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body class="hold-transition skin-blue sidebar-mini">
    <div id="loader" class="center"></div> 
    <div class="wrapper">
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <ol class="breadcrumb">
                    <li><a href="<?php echo base_url() . 'Home/index/' ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#"> GST Proforma Invoice</a></li>
                    <li class="active">GST Proforma Invoice Details</li>
                </ol>
            </section>

            <!-- Main content -->
            <section class="content">

                <label for="inputEmail3" name="invoice_number" id="invoice_number" class="col-sm-12 control-label"><h2>GST Proforma Invoice:<?php echo $invoice_data_group['invoice_number']; ?></h2></label>

                <div class="row" style="padding:2%">
                    <div class="pull-left">

                        <div class="col-md-2">
                            <a href="<?php echo base_url(); ?>ProformaInvoiceController/edit_proforma_invoice_details/<?php echo $invoice_data_group['invoice_number']; ?>" class="btn btn-primary edit-stock-qty" role="button">Edit</a>
                        </div>

                        <div class="pull-right">
                            
                            <div class="col-md-3 dropdown">
                                <div class="dropdown">
                                    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Send <b class="caret"></b>
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li><a class="dropdown-item" href="#">Send Invoice</a></li>
                                        <li class="divider"></li>
                                        <li><a class="dropdown-item" href="https://www.gmail.com"><img src="<?php echo base_url(); ?>uploads/gmail.jpg" class="send-icon" alt="Gmail" style="width:28px;height: 18px;"> Gmail</a></li>
                                        <li><a class="dropdown-item" href="https://login.yahoo.com"><img src="<?php echo base_url(); ?>uploads/yahoo.jpg" class="send-icon" alt="Yahoo Mail" style="width:28px;height: 31px;"> Yahoo! Mail</a></li>
                                        <li><a class="dropdown-item" href="https://outlook.live.com/owa/?authRedirect=true"><img src="<?php echo base_url(); ?>uploads/hotmail.jpg" class="send-icon" alt="Outlook" style="width:28px;height: 31px;"> Outlook</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-2 dropdown">

                                <div class="dropdown">
                                    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        More <b class="caret"></b>
                                    </button>
                                    <input type="hidden" class="form-control input-sm"  name="invoice_number" id="invoice_number" required="" value="<?php echo $invoice_data_group['invoice_number']; ?>">  
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li class="hide"><a class="dropdown-item" href="<?php echo base_url(); ?>LoginController/get_settings/">Edit Business Information</a></li>
                                        <li><a class="dropdown-item" id="exportpdf" href="<?php echo base_url(); ?>Pdf/download_proforma_invoice/<?php echo $invoice_data_group['invoice_number']; ?>">Export as pdf</a></li>
                                    
                                    
                                    </ul>
                                   
                                   
                                </div>
                            </div>
                        </div>
                        
                         <div class="col-md-2">
                                  <button id="convertToInvoice" class="btn btn-primary" role="button" type="submit">Convert to Invoice</button>
                                    </div>
                        
                    </div>
                </div>
                <!-- /.box-header -->

             <div class="shadows1">
                    <div class="row">
                        <section>
                            <div class="col-xs-6">
                                <div>
                                    <center><img src="<?php echo base_url() . $settings['company_logo'] ?>" width="30%" height="15%" style="margin-top:26px;"></center>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="contemporary-template__header__info">
                                    <div class="wv-heading--title"><h3>PROFORMA INVOICE</h3></div>
                                    <div class="wv-heading--subtitle"></div>
                                    <span class="wv-text--strong" style="font-size: 1.2em;"><?php echo $settings['company_name']; ?></span><br>
                                    <span class="wv-text--strong"><b>GST Number : </b> <?php echo $settings['company_gst']; ?></span><br>
                                    <span class="wv-text--strong"><b>PAN Number : </b> <?php echo $settings['company_pan']; ?></span><br>
                                    <span class="wv-text--strong"><b>Mobile Number : </b> <?php echo $settings['mobile']; ?></span><br>
                                    <span class="wv-text--strong"><b>Email ID : </b> <?php echo $settings['email']; ?></span><br>
                                    <span class="wv-text--strong"><b>State Code : </b> <?php echo $settings['state_code']; ?></span><br>
                                    <span class="wv-text--strong"><b>Address : </b> <?php echo $settings['address']; ?></span>
                                    
                                </div>
                            </div>
                        </section>

                    </div>
                    <hr>
                    <div class="row">

                        <div class="col-xs-4">

                            <div class="form-group row ">
                                <label for="inputEmail3" id="subheading1" class="col-sm-4 control-label"><b>BILL TO:</b></label>
                            </div>
                            
                            
                            
                            
                            <div class="contemporary-template__header__info">
<!--                                    <div class="wv-heading--title"><h3>TAX INVOICE</h3></div>-->
                                    <div class="wv-heading--subtitle"></div>
                                    <span class="wv-text--strong"><b>Company Name: </b>  <?php echo $invoice_data_group['company_name']; ?></span>
                                    
                                   <span class="wv-text--strong"> <?php echo $invoice_data_group['address']; ?></span><br>
                                    <span class="wv-text--strong"><b>State Code : </b> <?php if ($invoice_data_group['state_code']) { ?>
                                        <?php echo $invoice_data_group['state_code']; ?>
                                    <?php } else { ?>
                                        <?php
                                        echo "None Provided";
                                    }
                                    ?></span><br>
                                    <span class="wv-text--strong"><b>GST Number : </b> <?php if ($invoice_data_group['gst']) { ?>
                                        <?php echo $invoice_data_group['gst']; ?>
                                    <?php } else { ?>
                                        <?php
                                        echo "None Provided";
                                    }
                                    ?></span><br>
                                    <span class="wv-text--strong"><b>PAN Number : </b> <?php if ($invoice_data_group['pancard']) { ?>
                                        <?php echo $invoice_data_group['pancard']; ?>
                                    <?php } else { ?>
                                        <?php
                                        echo "None Provided";
                                    }
                                    ?></span><br>
                                    <span class="wv-text--strong"><b>KIND ATTN : </b> <?php echo $invoice_data_group['fullname']; ?></span><br>
                                    <span class="wv-text--strong"><b>Customer PO : </b> <?php if ($invoice_data_group['customer_po']) { ?>
                                        <?php echo $invoice_data_group['customer_po']; ?>
                                    <?php } else { ?>
                                        <?php
                                        echo "None Provided";
                                    }
                                    ?></span><br>
                                    <span class="wv-text--strong"><b>PO Date : </b> <?php if ($invoice_data_group['po_date']) { ?>
                                        <?php echo $invoice_data_group['po_date']; ?>
                                    <?php } else { ?>
                                        <?php
                                        echo "None Provided";
                                    }
                                    ?></span><br>
                                    
                                      <span class="wv-text--strong"><b>Supplier Code : </b> <?php if ($invoice_data_group['supplier_code']) { ?>
                                        <?php echo $invoice_data_group['supplier_code']; ?>
                                    <?php } else { ?>
                                        <?php
                                        echo "None Provided";
                                    }
                                    ?></span>
                                    
                                </div>
                            

                        </div>

                        <div class="col-xs-4">

                            <div class="form-group row ">
                                <div class="col-sm-12">
                                   <?php if(isset($invoice_data_group['shipping_address'])) { ?><label class="control-label"><b>SHIPPING TO: </b></label> <br> <?php } ?>
                                         <?php echo $invoice_data_group['shipping_address']; ?>
                                </div>
                            </div>

                            
                        </div>
                        
                        
                         <div class="col-xs-4">    
                            
                            <div class="contemporary-template__header__info">
                                 <label class="control-label"><b>INVOICE DETAILS:</b></label> 
                                 <br>
<!--                                    <span class="wv-text--strong" style="font-size: 1.2em;"><b><?php echo $settings['company_name']; ?></b></span><br>-->
                                    <span class="wv-text--strong"><b>Invoice Number : </b> <?php echo $invoice_data_group['invoice_number']; ?></span><br>
                                 <span class="wv-text--strong"><b>Invoice Date : </b> <?php echo date('d-m-Y', strtotime($invoice_data_group['invoice_date'])); ?></span><br>
                                    <span class="wv-text--strong"><b>Delivery Note No : </b> <?php echo $invoice_data_group['delivery_note_no']; ?></span><br>
                                    <span class="wv-text--strong"><b>Delivery Date : </b> <?php echo $invoice_data_group['delivery_date']; ?></span><br>
                                    <span class="wv-text--strong"><b>Dispatch through : </b> <?php echo $invoice_data_group['despatch_through']; ?></span><br>
                                    <span class="wv-text--strong"><b>Vehicle No: </b> <?php echo $invoice_data_group['vehicle_no']; ?></span><br>
                                    <span class="wv-text--strong"><b>Payment mode: </b> <?php if ($invoice_data_group['payment_method'] == '1') { ?>
                                        <?php echo "By Cash"; ?>
                                    <?php } else if ($invoice_data_group['payment_method'] == '2') { ?>
                                        <?php
                                        echo "By Cheque";
                                    } else if ($invoice_data_group['payment_method'] == '3') {
                                        ?>
                                        <?php
                                        echo "By NetBanking";
                                    } else {
                                        ?>
                                        <?php
                                        echo "None Provided";
                                    }
                                    ?></span>
                                </div>
                            

                        </div>
                    </div>
                    <br>
                    <div class="table-responsive">  

                        <table class="table table-bordered" id="dynamic_field">  
                            <tr>
                                <th>Sr.No.</th>
                                <th>Description</th>
                                <th>HSN Code</th>
                                <th>Qty(Nos/Kg)</th>
                                <th>GST(%)</th>
                                <th class="gst">SGST</th>
                                <th class="gst">CGST</th>
                                <th class="igst">IGST</th>
                                <th>Price</th>
    <!--                                <th>Discount(%)</th>-->
                                <th>Amount</th>
                            </tr>
                            <?php
                            $i = 1;
                            $sgst_total_amt = 0;
                            $igst_total_amt = 0;
                            $amt = 0;
                            foreach ($show_invoice as $key) {
                                ?>
                                <?php $sgst_total_amt = $sgst_total_amt + $key->cgst; ?>
                                <?php $igst_total_amt = $igst_total_amt + $key->igst; ?>
                                <tr> 
                                    <td><span id="" class=""></span>
                                        <?php echo $i; ?>
                                    </td>

                                    <td><span id="" class=""></span>
                                        <b><?php echo $key->product_name; ?></b>
                                        <?php echo $key->description; ?>
                                              <input type="hidden" name="term[]" value="<?php echo $key->product_name; ?>" id="item_name<?php echo $i; ?>" class="form-control input-sm name_list product_name_auto" />
                                    </td>

                                    <td><span id="" class=""></span>
                                        <?php echo $key->hsn_code; ?><input type="hidden" name="hsn[]" value="<?php echo $key->hsn_code; ?>" id="hsn<?php echo $i; ?>" class="form-control input-sm name_list" /> 
                                    </td>

                                    <td><span id="" class=""></span>
                                        <?php echo number_format($key->quantity, 2); ?><input type="hidden" name="quantity[]" value="<?php echo $key->quantity; ?>" id="quantity<?php echo $i; ?>" class="form-control input-sm name_list quantity_auto" value="1" />
                                    </td>

                                    <td><span id="" class=""></span>
                                        <?php echo $key->gst; ?><input type="hidden" name="gst_per[]" value="<?php echo $key->gst; ?>" id="gst_per<?php echo $i; ?>" class="form-control input-sm name_list" />
                                    </td>

                                    <?php if ($key->gst_type != 'I') { ?>
                                        <td class="gst"><span id="" class=""></span>
                                            <input type="hidden" name="gst" value="gst" id="gst">
                                            <?php echo number_format($key->sgst, 2); ?><input type="hidden" name="sgst[]" value="<?php echo $key->sgst; ?>"  id="sgst<?php echo $i; ?>" class="form-control input-sm sgst_list" />
                                        </td>

                                        <td class="gst"><span id="" class=""></span>
                                            <?php echo number_format($key->cgst, 2); ?><input type="hidden" name="cgst[]" value="<?php echo $key->cgst; ?>" id="cgst<?php echo $i; ?>" class="form-control input-sm cgst_list" />
                                        </td>
                                    <?php } else { ?>

                                        <td class="igst">
                                            <span id="" class=""></span><?php echo number_format($key->igst, 2); ?>
                                            <input type="hidden" name="igst" value="igst" id="igst">
                                            <input type="hidden" name="igst[]" value="<?php echo $key->igst; ?>" id="igst<?php echo $i; ?>" class="form-control input-sm igst_list" />
                                        </td>
                                    <?php } ?>



                                    <td><span id="" class=""></span>
                                        <?php echo number_format($key->price, 2); ?><input type="hidden" name="price[]" value="<?php echo $key->price; ?>" id="price<?php echo $i; ?>" class="form-control input-sm name_list"/>

                                    </td>


<!--                                    <td><span id="" class=""></span>
                                        <?php echo number_format($key->discount, 2); ?><input type="hidden" name="discount[]" id="discount<?php echo $i; ?>" class="form-control input-sm name_list" value="<?php echo $key->discount; ?>"/>

                                    </td>-->



                                    <td><span id="" class=""></span>
                                        <?php echo number_format($key->amount, 2); 
                                         $amt += $key->amount;$amt
                                        ?><input type="hidden" name="amount[]" id="amount<?php echo $i; ?>" class="form-control input-sm name_list amount_auto" value="<?php echo $key->amount; ?>"/>

                                    </td>


                                </tr>  

                                <?php
                                $i++;
                            }
                            ?>
                            <?php
                            $i = 1;
                            foreach ($show_invoice as $key) {
                                ?>
                                <?php if ($key->gst_type != 'I') { ?>

                                           <tr class="">
                                            <td colspan="8"  class="text-right">
                                                Total before tax: 
                                            </td>
                                            <td colspan="1"  class="text-left">
                                                ₹ <?php echo $amt; ?>
                                            </td>
                                            
                             </tr> 
                                    <tr>
                                        <td colspan="8"  class="text-right">
                                            <label class="control-label"><b>CGST Amount : </b></label>
                                        </td>

                                        <td colspan="1"  class="text-left">
                                            <b><?php echo number_format($sgst_total_amt, 2); ?></b><br>
                                        </td>

                                    </tr>

                                    <tr>
                                        <td colspan="8"  class="text-right">
                                            <label class="control-label"><b>SGST Amount : </b></label>
                                        </td>
                                        <td colspan="1"  class="text-left">
                                            <b><?php echo number_format($sgst_total_amt, 2); ?></b><br>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td colspan="8"  class="text-right">
                                            <label class="control-label"><b>Grand Total (INR) : </b></label>
                                        </td>
                                        <td colspan="1"  class="text-left">
                                            <b>₹<?php echo number_format($invoice_data_group['total'], 2); ?></b> <br>
                                        </td>
                                    </tr>
                                    
                                      <tr>
                                        <td colspan="8"  class="text-right">
                                            <label class="control-label"><b>Balance (INR) : </b></label>
                                        </td>
                                        <td colspan="1"  class="text-left">
                                            <b>₹<?php echo number_format($invoice_data_group['balance'], 2); ?></b> <br>
                                        </td>
                                    </tr>
                                    <tr></tr>

                                    <tr>
                                        <td colspan="10"  class="text-right">
                                            <?php
                                            // include amount_convert
                                            require( APPPATH . '/third_party/amount_convert.php');
                                            ?>
                                            <b>Balance Amount in Words:<?php echo number_to_word($invoice_data_group['balance']); ?> Only.</b><br>
                                        </td>
                                    </tr>

                                <?php } else { ?>
                                    
                                     <tr class="">
                                            <td colspan="7"  class="text-right">
                                                Total before tax: 
                                            </td>
                                            <td colspan="1"  class="text-left">
                                                ₹ <?php echo $amt; ?>
                                            </td>
                                            
                             </tr> 

                                    <tr>
                                        <td colspan="7"  class="text-right">
                                            <label class="control-label"><b>IGST Amount : </b></label>
                                        </td>

                                        <td colspan="1"  class="text-left">
                                            <b> <?php echo number_format($igst_total_amt, 2); ?></b><br>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td colspan="7"  class="text-right">
                                            <label class="control-label"><b>Grand Total (INR) : </b></label>
                                        </td>

                                        <td colspan="1"  class="text-left">
                                            <b>₹<?php echo number_format($invoice_data_group['total'], 2); ?></b> <br>
                                        </td>

                                    </tr>
                                    
                                                        <tr>
                                        <td colspan="7"  class="text-right">
                                            <label class="control-label"><b>Balance (INR) : </b></label>
                                        </td>

                                        <td colspan="1"  class="text-left">
                                            <b>₹<?php echo number_format($invoice_data_group['balance'], 2); ?></b> <br>
                                        </td>

                                    </tr>
                                    
                                    <tr>
                                        <td colspan="9"  class="text-right">
                                            <?php
                                            // include amount_convert
                                            require( APPPATH . '/third_party/amount_convert.php');
                                            ?>
                                            <b>Balance Amount in Words:<?php echo number_to_word($invoice_data_group['balance']); ?> Only.</b><br>
                                        </td>
                                    </tr>

                                    <tr>

                                    </tr>
                                <?php } ?>

                                <?php
                                $i++;
                                break;
                            }
                            ?>
                        </table>   

                     
                        
                        
                        
                          <div class="row">
                            <center> <b><h4>Payment History</h4></b></center>
                            <div class="col-sm-12">
                                <table class="table table-bordered table-striped" id="">  
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Date</th>
                                        <th>Payment Type</th>
                                        <th>Note</th>
                                        <th>Paid Amount</th>
                                    </tr>
                                    <?php
                                    $j = 1;
                                    foreach ($payment_history as $key) {
                                        ?>
                                        <tr> 
                                            <td><span id="" class=""></span>
                                                <?php echo $j; ?>
                                            </td>
                                            <td><span id="" class=""></span>
                                                <?php echo date('d-m-Y', strtotime($key->invoice_pay_date)); ?>
                                            </td>
                                            <td><span id="" class=""></span>
                                                <?php echo $key->payment_type; ?>
                                            </td>
                                            <td><span id="" class=""></span>
                                                <?php echo $key->invoice_pay_remark; ?>
                                            </td>
                                            <td><span id="" class=""></span>
                                                <?php echo $key->invocie_pay_amount; ?>
                                            </td>
                                        </tr>
                                        <?php
                                        $j++;
                                    }
                                    ?>
                                </table>
                            </div>

                        </div>

                        <div class="col-sm-12">
                            <textarea style="overflow: auto;
                                      border: none;" class="form-control" readonly="" name="notes" id="quotation_memo" rows="8"><?php echo $settings['invoice_notes']; ?></textarea>
                        </div>
                        <div class="form-group row ">
                            <label for="inputEmail3" class="col-sm-9 control-label"><b>Receivers Signatory :</b></label>
                            <label for="inputEmail3" class="col-sm-3 control-label"><b> Authorized Signatory :</b></label>
                        </div>

                        <div style="text-align: center;">This is Computer Generated Invoice</div><br>

                    </div>  
                </div>


            </section>
            <!-- /.content -->
        </div>
        <?php $this->load->view('admin/footer'); ?>
    </div>
    <!-- ./wrapper -->
    <script>

        $(document).ready(function () {

            var igst = $("#igst").val();
            //alert(igst);
            if (igst == "igst") {
                $(".gst").hide();
                $(".igst").show();

            } else {
                $(".gst").show();
//                 $(".gst"). css('padding','10% 0% 0% 0%')
                $(".igst").hide();
            }

        });
    </script>